Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

//Correlation comment - Do not change!  Original value='books' Name ='C_Category' Type ='Manual'/

/*Correlation comment - Do not change!  Original value='books' Name ='C_Category' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_Category",
		"RegExp=a\\ href=\"/(.*?)\">\\\r",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/demowebshop.tricentis.com/*",
		LAST);

	web_url("demowebshop.tricentis.com", 
		"URL=https://demowebshop.tricentis.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/Themes/DefaultClean/Content/images/top-menu-divider.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/bullet-right.gif", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/star-x-active.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/loading.gif", "Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/star-x-inactive.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/arrows.png", "Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", ENDITEM, 
		"Url=/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/bullets.png", "Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/top-menu-triangle.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/top-menu-background.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/top-menu-list-image.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/top-menu-list-image-hover.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/ico-arrow-r.gif", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/free-shipping.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/ajax_loader_large.gif", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/ico-close-notification-bar.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/ajax_loader_small.gif", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-bg_highlight-soft_75_cccccc_1x100.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-icons_888888_256x240.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-bg_glass_75_e6e6e6_1x400.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-icons_454545_256x240.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-bg_glass_75_dadada_1x400.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-icons_222222_256x240.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-bg_glass_65_ffffff_1x400.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=/Themes/DefaultClean/Content/images/arrow-up.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		LAST);

	lr_start_transaction("1_LaunchURL");

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790836606237\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	//Connection ID 0 received buffer WebSocketReceive0/

	lr_end_transaction("1_LaunchURL",LR_AUTO);

	lr_start_transaction("2_Register");

	web_url("Register", 
		"URL=https://demowebshop.tricentis.com/register", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("2_Register",LR_AUTO);

	lr_start_transaction("3_RegisterDetails");

	web_submit_data("register", 
		"Action=https://demowebshop.tricentis.com/register", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/register", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=__RequestVerificationToken", "Value=S3jQi0_L2eH4kyR3YzMIJbnMbzU9yrbHLTj7TOTJcBF-MO0-eXNraY_Vraz8fwgCxxDVtQFO_REHrqT_6iCVogWVFTEZhLHcAINfUgl01181", ENDITEM, 
		"Name=Gender", "Value={P_Gender}", ENDITEM, 
		"Name=FirstName", "Value={P_FirstName}", ENDITEM, 
		"Name=LastName", "Value={P_LastName}", ENDITEM, 
		"Name=Email", "Value={P_Email}", ENDITEM, 
		"Name=Password", "Value={P_Password}", ENDITEM, 
		"Name=ConfirmPassword", "Value={P_Password}", ENDITEM, 
		"Name=register-button", "Value=Register", ENDITEM, 
		LAST);

	web_url("Tricentis Demo Web Shop", 
		"URL=https://demowebshop.tricentis.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/registerresult/1", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("3_RegisterDetails",LR_AUTO);

	lr_start_transaction("4_Category");

//Correlation comment - Do not change!  Original value='computing-and-internet' Name ='C_Product' Type ='Manual'/
	web_reg_save_param_regexp(
		"ParamName=C_Product",
		"RegExp=a\\ href=\"/(.*?)\"\\ title",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("Books",
		"URL=https://demowebshop.tricentis.com/{C_Category}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://demowebshop.tricentis.com/",
		"Snapshot=t6.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("4_Category",LR_AUTO);

	lr_think_time(9);

	lr_start_transaction("5_Product");

	web_url("Computing and Internet",
		"URL=https://demowebshop.tricentis.com/{C_Product}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://demowebshop.tricentis.com/{C_Category}",
		"Snapshot=t7.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=/content/images/thumbs/0000130_{C_Product}_47.jpeg", ENDITEM,
		LAST);

	lr_end_transaction("5_Product",LR_AUTO);

	lr_start_transaction("6_AddToCart");

	web_submit_data("1",
		"Action=https://demowebshop.tricentis.com/addproducttocart/details/13/1",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=application/json",
		"Referer=https://demowebshop.tricentis.com/{C_Product}",
		"Snapshot=t8.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=addtocart_13.EnteredQuantity", "Value=1", ENDITEM,
		LAST);

	lr_end_transaction("6_AddToCart",LR_AUTO);

	lr_think_time(13);

	lr_start_transaction("7_Cart");

	web_url("cart",
		"URL=https://demowebshop.tricentis.com/cart",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://demowebshop.tricentis.com/{C_Product}",
		"Snapshot=t9.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("7_Cart",LR_AUTO);

	lr_start_transaction("8_Checkout");

	web_url("getstatesbycountryid", 
		"URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=93&addEmptyStateIfRequired=true&_=1790845413865", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_data("cart_2", 
		"Action=https://demowebshop.tricentis.com/cart", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=itemquantity7121418", "Value=1", ENDITEM, 
		"Name=discountcouponcode", "Value=", ENDITEM, 
		"Name=giftcardcouponcode", "Value=", ENDITEM, 
		"Name=CountryId", "Value=93", ENDITEM, 
		"Name=StateProvinceId", "Value=0", ENDITEM, 
		"Name=ZipPostalCode", "Value=", ENDITEM, 
		"Name=termsofservice", "Value=on", ENDITEM, 
		"Name=checkout", "Value=checkout", ENDITEM, 
		EXTRARES, 
		"Url=/plugins/Payments.CashOnDelivery/logo.jpg", "Referer=https://demowebshop.tricentis.com/onepagecheckout", ENDITEM, 
		"Url=/plugins/Payments.Manual/logo.jpg", "Referer=https://demowebshop.tricentis.com/onepagecheckout", ENDITEM, 
		"Url=/plugins/Payments.PurchaseOrder/logo.jpg", "Referer=https://demowebshop.tricentis.com/onepagecheckout", ENDITEM, 
		"Url=/plugins/Payments.CheckMoneyOrder/logo.jpg", "Referer=https://demowebshop.tricentis.com/onepagecheckout", ENDITEM, 
		LAST);

	lr_end_transaction("8_Checkout",LR_AUTO);

	lr_think_time(16);

	lr_start_transaction("9_Confirm");

	web_url("getstatesbycountryid_2", 
		"URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=93&addEmptyStateIfRequired=true&_=1790845435723", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(14);

	web_submit_data("OpcSaveBilling", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=BillingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.FirstName", "Value={P_FirstName}", ENDITEM, 
		"Name=BillingNewAddress.LastName", "Value={P_LastName}", ENDITEM, 
		"Name=BillingNewAddress.Email", "Value=akhilae69@gmail.com", ENDITEM, 
		"Name=BillingNewAddress.Company", "Value=", ENDITEM, 
		"Name=BillingNewAddress.CountryId", "Value={P_Country}", ENDITEM, 
		"Name=BillingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.City", "Value={P_City}", ENDITEM, 
		"Name=BillingNewAddress.Address1", "Value={P_Address}", ENDITEM, 
		"Name=BillingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=BillingNewAddress.ZipPostalCode", "Value={P_ZipCode}", ENDITEM, 
		"Name=BillingNewAddress.PhoneNumber", "Value={P_PhoneNo}", ENDITEM, 
		"Name=BillingNewAddress.FaxNumber", "Value=", ENDITEM, 
		LAST);

	web_submit_data("OpcSaveShipping", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=shipping_address_id", "Value=5159694", ENDITEM, 
		"Name=ShippingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.FirstName", "Value={P_FirstName}", ENDITEM, 
		"Name=ShippingNewAddress.LastName", "Value={P_LastName}", ENDITEM, 
		"Name=ShippingNewAddress.Email", "Value={P_Email}", ENDITEM, 
		"Name=ShippingNewAddress.Company", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.CountryId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.City", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address1", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.ZipPostalCode", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.PhoneNumber", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.FaxNumber", "Value=", ENDITEM, 
		"Name=PickUpInStore", "Value=false", ENDITEM, 
		LAST);

	web_submit_data("OpcSaveShippingMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShippingMethod/", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=shippingoption", "Value=Ground___Shipping.FixedRate", ENDITEM, 
		LAST);

	web_submit_data("OpcSavePaymentMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentMethod/", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=paymentmethod", "Value=Payments.CashOnDelivery", ENDITEM, 
		LAST);

	web_custom_request("OpcSavePaymentInfo", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcSavePaymentInfo/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("OpcConfirmOrder", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcConfirmOrder/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("completed", 
		"URL=https://demowebshop.tricentis.com/checkout/completed/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("9_Confirm",LR_AUTO);

	return 0;
}